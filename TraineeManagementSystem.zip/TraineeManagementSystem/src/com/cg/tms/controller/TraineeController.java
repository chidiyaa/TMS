package com.cg.tms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.tms.entities.Admin;
import com.cg.tms.entities.Trainee;
import com.cg.tms.service.TraineeManagementService;


@Controller
public class TraineeController {
	@Autowired
	TraineeManagementService tser;
	Trainee traineeSer;
	Trainee traineeSer1;
	@RequestMapping("start")
	public String user(Model model){
		
		Admin udetails=new Admin();
		model.addAttribute("udetails",udetails);
		return "login";
	}
	@RequestMapping("login")
	public String validation(@Valid@ModelAttribute("udetails")Admin udetails,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("udetails", udetails);
			return "login";
		}else{
			if(udetails.getUname().equals("Abhijith") && udetails.getPassword().equals("Abhijith")){
				return "success";}
			else
				return "login";

		}
	}
	@RequestMapping("retreiveall")
	public String showHome(Model model){
		List<Trainee> tlist=tser.getAllTrainees();
		model.addAttribute("tlist",tlist);
		return "retreiveallsuccess";
}
	@RequestMapping("add")
	public String showInsertPage(Model model){
		Trainee trainee=new Trainee();
		model.addAttribute("trainee",trainee);
		return "insertpage";
	}
	@RequestMapping("insertnow")
	public String inserttrainee(@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("trainee", trainee);
			return "insertpage";
		}else{
			
			tser.insertTrainee(trainee);
			model.addAttribute("trainee",trainee);
			return "insertsuccess";

		}
	}
	@RequestMapping("delete")
	public String showDeletePage(Model model){
		Trainee trainee=new Trainee();
		model.addAttribute("trainee",trainee);
		return "deletepage";
	}
	@RequestMapping("deletenow")
	public String deletetrainee(@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("trainee", trainee);
			System.out.println(res.hasErrors());
			return "success";
		}else{
			
			tser.deleteTrainee(traineeSer.getTraineeId());
			model.addAttribute("trainee",trainee);
			return "deletesuccess";

		}
	}
	@RequestMapping("modify")
	public String showUpdatePage(Model model){
		Trainee trainee=new Trainee();
		model.addAttribute("trainee",trainee);
		return "updatepage";
	}
	@RequestMapping("modifynow")
	public String updatetrainee(@Valid@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		if(res.hasErrors()){
			model.addAttribute("trainee", trainee);
			return "success";
		}else{
			
			tser.updateTrainee(trainee);
			//model.addAttribute("trainee",trainee);
			return "updatesuccess";

		}
	}
	/*@ModelAttribute("domainList")
    public Map<String, String> getdomainList() {
       Map<String, String> domainList = new HashMap<String, String>();
       domainList.put("JEE Cloud", "JEE Cloud");
       domainList.put("Full Stack Java", "Full Stack Java");
       domainList.put("Systems", "Systems");
       domainList.put("Main Frames", "Main Frames");
       return domainList;
    }*/
	@RequestMapping("search")
	public String showSearchPage(Model model){
		Trainee trainee=new Trainee();
		model.addAttribute("trainee",trainee);
		return "searchpage";
	}
	@RequestMapping("searchnow")
	public String searchTrainee(@Valid@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		 traineeSer=tser.searchTrainee(trainee);
		model.addAttribute("trainee",traineeSer);
		model.addAttribute("flag",true);
		return "deletepage";
}
	@RequestMapping("searchnow1")
	public String upTrainee(@Valid@ModelAttribute("trainee")Trainee trainee,BindingResult res,Model model){
		 traineeSer1=tser.searchTrainee(trainee);
		model.addAttribute("trainee",traineeSer1);
		model.addAttribute("flag",true);
		return "updatepage";
}
}
	

