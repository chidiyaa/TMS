package com.cg.tms.dao;

import java.util.List;


import com.cg.tms.entities.Trainee;


public interface traineeDao {
	List<Trainee>fetchAllTrainee();
	void insertTrainee(Trainee t);
	public void deleteTrainee(int tid);
	public void updateTrainee(Trainee t);
	public Trainee searchTrainee(Trainee t);
	/*public int addTrainee(Trainee t) throws TraineeException;
	public int updateTrainee(int tid)throws TraineeException;
	public int deleteTrainee(int tid)throws TraineeException;
*/
}
