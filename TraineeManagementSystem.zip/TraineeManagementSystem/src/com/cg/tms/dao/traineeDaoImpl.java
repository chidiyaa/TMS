package com.cg.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.tms.entities.Trainee;
@Repository
public class traineeDaoImpl implements traineeDao {
	@PersistenceContext
	private EntityManager em;
	@Override
	public List<Trainee> fetchAllTrainee() {
		// TODO Auto-generated method stub
		String jpql="SELECT m FROM Trainee m";
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
		return query.getResultList();
	}
	@Override
	public void insertTrainee(Trainee t) {
		// TODO Auto-generated method stub
		em.persist(t);
		
		
	}
	@Override
	public void deleteTrainee(int tid) {
		// TODO Auto-generated method stub
		String jpql="DELETE FROM Trainee c WHERE c.traineeId =?";
		Query query = em.createQuery(jpql);
	    query.setParameter(1, tid);
	    int count=query.executeUpdate();

	}
	@Override
	public void updateTrainee(Trainee t) {
		// TODO Auto-generated method stub
Trainee traineeToModify=em.find(Trainee.class,(int) t.getTraineeId());
        
        traineeToModify.setTraineeDomain(t.getTraineeDomain());
        traineeToModify.setTraineeLocation(t.getTraineeLocation());
        traineeToModify.setTraineeName(t.getTraineeName());
        //em.remove(trainee);
       
        em.persist(traineeToModify);
		
	}
	@Override
	public Trainee searchTrainee(Trainee t) {
		// TODO Auto-generated method stub
		
		return em.find(Trainee.class,(int) t.getTraineeId());
	}
	
	

}
