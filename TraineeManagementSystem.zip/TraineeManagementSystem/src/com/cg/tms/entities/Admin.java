package com.cg.tms.entities;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Admin {
	@NotEmpty(message="Enter uname")
private String uname;
	@NotEmpty(message="Enter password")
	@Size(min = 2, max = 10, message = "Your password must between 2 and 15 characters")
private String password;
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Admin(String uname, String password) {
	super();
	this.uname = uname;
	this.password = password;
}
public Admin() {
	super();
}
@Override
public String toString() {
	return "Admin [uname=" + uname + ", password=" + password + "]";
}

}
