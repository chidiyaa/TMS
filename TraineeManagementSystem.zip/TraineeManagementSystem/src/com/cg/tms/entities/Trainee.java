package com.cg.tms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="trainee")
public class Trainee {
	@Id
	@Column(name="traineeid")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_trainee_id_1",allocationSize=1)
private int traineeId;
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="[A-z][a-zA-Z]{3,15}",message="Name should contain letters only and size should be netween 3 to 15 letters")
	@Column(name="traineename")
private String traineeName;
	@NotEmpty(message="Domain is mandatory")
	//@Pattern(regexp="[A-z][a-zA-Z]{3,15}",message="domain should contain letters only and size should be netween 3 to 15 letters")
	@Column(name="traineedomain")
private String traineeDomain;
	@NotEmpty(message="Location is mandatory")
	//@Pattern(regexp="[A-z][a-zA-Z]{3,15}",message="location should contain letters only and size should be netween 3 to 15 letters")
	@Column(name="traineelocation")
private String traineeLocation;
public Trainee(int traineeId, String traineeName, String traineeDomain,
		String traineeLocation) {
	super();
	this.traineeId = traineeId;
	this.traineeName = traineeName;
	this.traineeDomain = traineeDomain;
	this.traineeLocation = traineeLocation;
}
public Trainee() {
	super();
}
public int getTraineeId() {
	return traineeId;
}
public void setTraineeId(int traineeId) {
	this.traineeId = traineeId;
}
public String getTraineeName() {
	return traineeName;
}
public void setTraineeName(String traineeName) {
	this.traineeName = traineeName;
}
public String getTraineeDomain() {
	return traineeDomain;
}
public void setTraineeDomain(String traineeDomain) {
	this.traineeDomain = traineeDomain;
}
public String getTraineeLocation() {
	return traineeLocation;
}
public void setTraineeLocation(String traineeLocation) {
	this.traineeLocation = traineeLocation;
}
@Override
public String toString() {
	return "Trainee [traineeId=" + traineeId + ", traineeName=" + traineeName
			+ ", traineeDomain=" + traineeDomain + ", traineeLocation="
			+ traineeLocation + "]";
}

}
