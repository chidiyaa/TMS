package com.cg.tms.service;

import java.util.List;
import com.cg.tms.entities.Trainee;


public interface TraineeManagementService {
	List<Trainee> getAllTrainees();
	void insertTrainee(Trainee t);
	public void deleteTrainee(int tid);
	public void updateTrainee(Trainee t);
	public Trainee searchTrainee(Trainee t);
}
