package com.cg.tms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.tms.dao.traineeDao;
import com.cg.tms.entities.Trainee;
@Transactional
@Service
public class TraineeManagementServiceImpl implements TraineeManagementService{
	@Autowired
	traineeDao tdao;
	@Override
	public List<Trainee> getAllTrainees() {
		// TODO Auto-generated method stub
		return tdao.fetchAllTrainee();
	}

	@Override
	public void insertTrainee(Trainee t) {
		// TODO Auto-generated method stub
		tdao.insertTrainee(t);
	}

	@Override
	public void deleteTrainee(int tid) {
		// TODO Auto-generated method stub
		 tdao.deleteTrainee(tid);
	}

	@Override
	public void updateTrainee(Trainee t) {
		// TODO Auto-generated method stub
		 tdao.updateTrainee(t);
		
	}

	@Override
	public Trainee searchTrainee(Trainee t) {
		// TODO Auto-generated method stub
		return tdao.searchTrainee(t);
	}
	

}
